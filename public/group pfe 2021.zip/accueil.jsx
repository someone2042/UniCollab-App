import React from "react";

export const Accueil = () =>{
    return(
        <div>
            <p className="under">hello</p>
        </div>
    )
}