var tab =new Array();
var taille = T.length;
if(n<= taille)
{
    for(i=taille-1;i>taille-n;i--)
    {
        tab[taille-1-i]=t[i];
    }
}
print("hello")