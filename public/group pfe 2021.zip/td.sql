

-- select max(moyen_total)
-- from(
--     select avg(moyen_matier) as moyen_total, et.ncin
--     from (
--         select avg(ep.note) as moyen_matier,et.ncin,m.code_matier
--         from epreuve ep join matier m using code_matier
--         join etudien using ncin
--         group by ncin and code_matier

--     )
-- )


DECLARE
    CURSOR c_etudiants IS
        SELECT DISTINCT e.ncin, et.nom
        FROM etudiant et
        JOIN epreuve e ON et.ncin = e.ncin;
    
    TYPE note_type IS TABLE OF epreuve.note%TYPE INDEX BY VARCHAR2(100);
    v_notes note_type;
    
    v_moyenne_matiere epreuve.note%TYPE;
    v_moyenne_generale NUMBER := 0;
    
    v_min_moyenne NUMBER := NULL;
    v_max_moyenne NUMBER := NULL;
    
    v_count NUMBER := 0;
BEGIN
select max(moyen_total) INTO v_max_moyenne,min(moyen_total) into v_min_moyenne
from(
    select avg(moyen_matier) as moyen_total, et.ncin
    from (
        select avg(ep.note) as moyen_matier,et.ncin,m.code_matier
        from epreuve ep join matier m using code_matier
        join etudien using ncin
        group by ncin and code_matier

    )
)
    FOR etudiant_rec IN c_etudiants LOOP
        DBMS_OUTPUT.PUT_LINE('Relevé de notes :');
        DBMS_OUTPUT.PUT_LINE('ncin : ' || etudiant_rec.ncin || '  nom : ' || etudiant_rec.nom);
        
        v_moyenne_generale := 0;
        v_count := 0;
        
        FOR matiere_rec IN (SELECT DISTINCT m.code_matiere, m.designation
                             FROM matiere m
                             JOIN epreuve e ON m.code_matiere = e.code_matiere
                             WHERE e.ncin = etudiant_rec.ncin) LOOP
            SELECT AVG(e.note)
            INTO v_moyenne_matiere
            FROM epreuve e
            WHERE e.ncin = etudiant_rec.ncin
            AND e.code_matiere = matiere_rec.code_matiere;
            
            -- v_notes(matiere_rec.designation) := v_moyenne_matiere;
            
            v_moyenne_generale := v_moyenne_generale + v_moyenne_matiere;
            v_count := v_count + 1;
            
            DBMS_OUTPUT.PUT_LINE('   ' || matiere_rec.designation || ' : ' || v_moyenne_matiere);
        END LOOP;
        
        v_moyenne_generale := v_moyenne_generale / v_count;
        
        DBMS_OUTPUT.PUT_LINE('Moyenne générale : ' || v_moyenne_generale);
        
        IF v_min_moyenne IS NULL OR v_moyenne_generale < v_min_moyenne THEN
            v_min_moyenne := v_moyenne_generale;
        END IF;
        
        IF v_max_moyenne IS NULL OR v_moyenne_generale > v_max_moyenne THEN
            v_max_moyenne := v_moyenne_generale;
        END IF;
        
        DBMS_OUTPUT.PUT_LINE('Récapitulatif :');
        DBMS_OUTPUT.PUT_LINE('Moyenne la plus basse : ' || v_min_moyenne);
        DBMS_OUTPUT.PUT_LINE('Moyenne la plus élevée : ' || v_max_moyenne);
        
        DBMS_OUTPUT.NEW_LINE;
    END LOOP;
END;


















